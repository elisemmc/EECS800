
# coding: utf-8

# In[6]:

from sklearn import datasets
import pandas as pd
import numpy as np
import math
import operator
from __future__ import division

#Please complete the following Naive Bayes code based on the given instructions


# Load the training and test dataset.

#Please handle the data with 'dataframe' type, remember to print/display the test and training datasets
train = #define
test = #define




groundtruth = test['target']


# We can use a Gaussian function to estimate the probability of a given attribute value, given the known mean and standard deviation for the attribute estimated from the training data.
# Knowing that the attribute summaries where prepared for each attribute and class value, the result is the conditional probability of a the attribute value given a class value.



def calcConditionalProb(testset,df_temp):
    '''
    This function takes the test dataset and a dataframe given one class label.
    The function returns the conditional probability given a column(feature).
    '''
    #hint: you can test.ix[:,i]
    prob = 1.0
    ###
    return prob


# Follow intructions for the given code snippet:

# In[ ]:

prob_df = pd.DataFrame()
#define a variable probTarget which is equal to the probablity of a given class.(upto 4 decimal places)
test = test.drop('target', axis = 1)
probTarget = #define


# For each label in the training dataset, we compute the probability of the test instances.



for label in train['target'].unique():
    df_temp = train[train['target']==label]
    df_temp = df_temp.drop('target', axis = 1)
    testset = test.copy(deep=True)
    prob_df[label] = (probTarget)*calcConditionalProb(testset, df_temp)


# Define a list 'prediction' that stores the label of the class with highest probability for each test instance which are stored in prob_df dataframe.



prediction = #define


# Calculate the accuracy of your model. The function should take the prediction and groundTruth as inputs and return the 
# confusion matrix. The confusion matrix is of 'dataframe' type.



def confusionMatrix(prediction, groundTruth):
    '''
    Return and print the confusion matrix.
    '''
    return confMatrix


# Call the confusionMatrix function and print the confusion matrix as well as the accuracy of the model.



groundTruth = ##
prediction = ##
conf = confusionMatrix(prediction, groundTruth)
accuracy = #define accuracy
print 'Accuracy = '+str(accuracy)+'%'

